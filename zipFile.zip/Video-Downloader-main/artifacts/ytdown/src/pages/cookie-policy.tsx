import { SEO } from "@/components/layout/seo";
import { Link } from "wouter";

const LAST_UPDATED = "July 1, 2026";

export default function CookiePolicyPage() {
  return (
    <div className="max-w-2xl mx-auto space-y-10">
      <SEO
        title="Cookie Policy"
        description="YTOUDown Cookie Policy — how we use cookies, what types we use, and how you can manage your preferences."
        path="/cookies"
        type="WebPage"
      />

      <div>
        <h1 className="text-3xl font-bold tracking-tight">Cookie Policy</h1>
        <p className="text-muted-foreground mt-2">
          Last updated: <time dateTime="2026-07-01">{LAST_UPDATED}</time>
        </p>
      </div>

      <div className="prose prose-neutral dark:prose-invert max-w-none space-y-8 text-sm leading-relaxed">

        <section>
          <h2 className="text-xl font-semibold mb-3">1. What Are Cookies?</h2>
          <p>
            Cookies are small text files placed on your device when you visit a website. They help websites
            remember your preferences, measure how pages are used, and support advertising services. Cookies
            are widely used across the internet and are generally safe and essential for many modern web features.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-3">2. How YTOUDown Uses Cookies</h2>
          <p>YTOUDown uses cookies and similar technologies for the following purposes:</p>
          <ul className="list-disc pl-5 space-y-2 mt-3">
            <li><strong>Website functionality</strong> — to ensure the website operates correctly and remembers session information.</li>
            <li><strong>Analytics</strong> — to understand how visitors interact with our pages, which helps us improve performance and content.</li>
            <li><strong>Advertising</strong> — to support advertising services (including Google AdSense) that may deliver personalized or non-personalized ads based on your browsing activity.</li>
            <li><strong>Preferences</strong> — to remember settings such as theme or language where applicable.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-3">3. Types of Cookies We Use</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold">Strictly Necessary Cookies</h3>
              <p>These cookies are required for the website to function and cannot be disabled. They do not collect personal information and are typically set in response to actions you take (e.g., setting preferences or filling in forms).</p>
            </div>
            <div>
              <h3 className="font-semibold">Analytics Cookies</h3>
              <p>These cookies help us understand how visitors use the site — such as which pages are visited most and whether users encounter errors. All information collected is aggregated and anonymous.</p>
            </div>
            <div>
              <h3 className="font-semibold">Advertising Cookies (Third-Party)</h3>
              <p>
                Our website may use Google AdSense and similar advertising technologies. These services use cookies,
                web beacons, and similar tracking technologies to serve relevant advertisements and measure
                their effectiveness. Google's use of advertising cookies enables it and its partners to serve ads
                based on your visits to this and other websites. You can opt out of personalized advertising by
                visiting <a href="https://www.google.com/settings/ads" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Google Ad Settings</a>.
              </p>
            </div>
          </div>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-3">4. Third-Party Cookies</h2>
          <p>
            Some cookies on our site are set by third-party services that appear on our pages. We do not
            control these cookies. Please refer to each third party's privacy and cookie policy for details:
          </p>
          <ul className="list-disc pl-5 space-y-1 mt-3">
            <li>Google LLC — <a href="https://policies.google.com/technologies/cookies" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Google Cookie Policy</a></li>
          </ul>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-3">5. Managing Cookies</h2>
          <p>
            You can control and manage cookies through your browser settings. Most browsers allow you to
            refuse some or all cookies, or to alert you when cookies are being sent. Please note that
            disabling cookies may affect the functionality of this and other websites.
          </p>
          <p className="mt-3">Instructions for managing cookies in common browsers:</p>
          <ul className="list-disc pl-5 space-y-1 mt-2">
            <li><a href="https://support.google.com/chrome/answer/95647" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Google Chrome</a></li>
            <li><a href="https://support.mozilla.org/en-US/kb/cookies-information-websites-store-on-your-computer" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Mozilla Firefox</a></li>
            <li><a href="https://support.microsoft.com/en-us/microsoft-edge/delete-cookies-in-microsoft-edge-63947406-40ac-c3b8-57b9-2a946a29ae09" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Microsoft Edge</a></li>
            <li><a href="https://support.apple.com/guide/safari/manage-cookies-sfri11471/mac" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Safari</a></li>
          </ul>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-3">6. Your Consent</h2>
          <p>
            By continuing to use YTOUDown, you acknowledge and consent to the use of cookies as described
            in this Cookie Policy. If you do not agree, you should adjust your browser settings or discontinue
            use of the site.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-3">7. Changes to This Policy</h2>
          <p>
            We may update this Cookie Policy from time to time. Any changes will be posted on this page
            with an updated date. We encourage you to review this policy periodically.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold mb-3">8. Contact</h2>
          <p>
            If you have questions about our use of cookies, please visit our{" "}
            <Link href="/contact" className="text-primary hover:underline">Contact page</Link> or review our{" "}
            <Link href="/privacy" className="text-primary hover:underline">Privacy Policy</Link>.
          </p>
        </section>

      </div>
    </div>
  );
}
