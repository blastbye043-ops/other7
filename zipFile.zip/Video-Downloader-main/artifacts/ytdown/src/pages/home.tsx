import { useState, useRef, useCallback } from "react";
import { useGetVideoInfo, useStartDownload, useGetDownloadStatus } from "@workspace/api-client-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Search, Loader2, Download, CheckCircle, AlertTriangle,
  FileVideo, FileAudio, Eye, Calendar, Zap, Globe, Smartphone,
  Layers, LayoutDashboard, Gift, Monitor, Chrome, ArrowRight,
  Clipboard, ClipboardCheck,
} from "lucide-react";
import { Link } from "wouter";
import { SEO } from "@/components/layout/seo";
import { CopyButton } from "@/components/copy-button";
import { formatDuration, formatViews, formatFilesize, formatDate } from "@/lib/format";
import { toast } from "sonner";
import { Progress } from "@/components/ui/progress";

const features = [
  { icon: Zap,             title: "Lightning Fast",          desc: "Our optimized processing retrieves video information and prepares your download in just seconds." },
  { icon: Globe,           title: "Browser Based",           desc: "No software downloads or browser extensions required. Everything runs directly in your web browser." },
  { icon: Smartphone,      title: "Mobile Friendly",         desc: "Works perfectly on Android phones, iPhones, tablets, laptops, and desktop computers." },
  { icon: Layers,          title: "Multiple Quality Options", desc: "Choose from all available video qualities based on the original upload — up to 4K where available." },
  { icon: LayoutDashboard, title: "Clean Interface",         desc: "Simple navigation makes downloading quick and hassle-free, with no clutter or confusing steps." },
  { icon: Gift,            title: "Free to Use",             desc: "No account creation or subscription needed. YTOUDown is completely free for everyone." },
];

const steps = [
  { n: "1", title: "Copy the URL",    desc: "Copy the YouTube video URL from your browser address bar or the YouTube app." },
  { n: "2", title: "Paste into YTOUDown", desc: "Paste the copied link into the search box on YTOUDown's home page." },
  { n: "3", title: "Choose & Download", desc: "Select your preferred quality from the available options and save the video to your device." },
];

const devices = ["Windows PC", "macOS", "Linux", "Android", "iPhone", "iPad", "Chromebook"];
const browsers = ["Google Chrome", "Mozilla Firefox", "Microsoft Edge", "Safari", "Opera", "Brave"];

const benefits = [
  "Fast video information retrieval",
  "Clean and responsive interface",
  "Browser-based — no installation",
  "No software or extension required",
  "Mobile-friendly design",
  "Easy navigation",
  "Multiple quality options",
  "Secure browsing experience",
  "No account or registration",
  "Regular platform improvements",
];

const YT_REGEX = /^(https?:\/\/)?(www\.)?(youtube\.com\/(watch\?.*v=|shorts\/|live\/)|youtu\.be\/).+/i;

export default function Home() {
  const [url, setUrl] = useState("");
  const [activeJobId, setActiveJobId] = useState<string | null>(null);
  const [pasteState, setPasteState] = useState<"idle" | "pasted">("idle");
  const inputRef = useRef<HTMLInputElement>(null);

  const videoInfoMutation = useGetVideoInfo();
  const startDownloadMutation = useStartDownload();

  const { data: jobStatus } = useGetDownloadStatus(activeJobId || "", {
    query: {
      queryKey: ["download-status", activeJobId],
      enabled: !!activeJobId,
      refetchInterval: (query) => {
        if (!query.state.data) return 2000;
        const status = query.state.data.status;
        return status === "pending" || status === "processing" ? 2000 : false;
      },
    },
  });

  const handlePaste = useCallback(async () => {
    if (!navigator.clipboard?.readText) {
      toast.error("Clipboard not supported", { description: "Your browser doesn't support clipboard access. Please paste manually." });
      return;
    }
    try {
      const text = (await navigator.clipboard.readText()).trim();
      if (!text) {
        toast.error("Clipboard is empty", { description: "Copy a YouTube link first, then click Paste." });
        return;
      }
      if (!YT_REGEX.test(text)) {
        toast.error("Not a YouTube link", { description: "Please copy a valid YouTube URL (youtube.com or youtu.be) first." });
        return;
      }
      setUrl(text);
      setPasteState("pasted");
      inputRef.current?.focus();
      setTimeout(() => setPasteState("idle"), 2000);
    } catch {
      toast.error("Clipboard access denied", { description: "Allow clipboard access in your browser, or paste the link manually." });
    }
  }, []);

  const handleGetInfo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) return;
    setActiveJobId(null);
    videoInfoMutation.mutate({ data: { url } }, {
      onError: (err) => toast.error("Failed to get video info", { description: err.data?.error }),
    });
  };

  const handleDownload = (formatId: string) => {
    if (!url) return;
    startDownloadMutation.mutate({ data: { url, formatId } }, {
      onSuccess: (data) => setActiveJobId(data.jobId),
      onError: (err) => toast.error("Failed to start download", { description: err.data?.error }),
    });
  };

  const video = videoInfoMutation.data;
  const isJobActive = jobStatus?.status === "pending" || jobStatus?.status === "processing";
  const jobDone = jobStatus?.status === "done";
  const jobFailed = jobStatus?.status === "failed";

  return (
    <div className="max-w-4xl mx-auto space-y-24">
      <SEO
        title="Fast YouTube Video Downloader — Download Videos Online"
        description="Download YouTube videos quickly with YTOUDown. Paste a YouTube URL, choose available quality options, and save videos using our fast, free, browser-based downloader."
        path="/"
        jsonLd={{
          "@type": "HowTo",
          name: "How to download a YouTube video with YTOUDown",
          step: [
            { "@type": "HowToStep", position: 1, name: "Copy the YouTube URL", text: "Copy the YouTube video URL from your browser." },
            { "@type": "HowToStep", position: 2, name: "Paste into YTOUDown", text: "Paste the link into the search box on YTOUDown." },
            { "@type": "HowToStep", position: 3, name: "Choose quality and download", text: "Select your preferred quality and save the file to your device." },
          ],
        }}
      />

      {/* ── Hero ── */}
      <section className="text-center space-y-6 pt-12 pb-4">
        <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight speakable">
          Download YouTube Videos<br />
          <span className="text-primary">Fast</span> with YTOUDown
        </h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto speakable">
          Save your favorite YouTube videos quickly using YTOUDown. Simply paste a YouTube video link,
          choose the available download quality, and download your video directly to your device.
          No software installation. No complicated setup. Just a fast and easy downloading experience.
        </p>

        <form onSubmit={handleGetInfo} className="flex gap-2 max-w-2xl mx-auto mt-8">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5 pointer-events-none" />
            <Input
              ref={inputRef}
              placeholder="https://www.youtube.com/watch?v=..."
              className="pl-12 pr-28 h-14 text-lg bg-card border-2 border-border focus-visible:ring-primary focus-visible:border-primary rounded-xl"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              disabled={videoInfoMutation.isPending || isJobActive}
              aria-label="YouTube video URL"
            />
            {/* ── Paste button ── */}
            <button
              type="button"
              onClick={handlePaste}
              disabled={videoInfoMutation.isPending || isJobActive}
              aria-label={pasteState === "pasted" ? "URL pasted successfully" : "Paste YouTube URL from clipboard"}
              className={[
                "absolute right-2 top-1/2 -translate-y-1/2",
                "inline-flex items-center gap-1.5 px-3 h-10 rounded-lg",
                "text-sm font-medium transition-all duration-200 select-none",
                "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-1",
                "disabled:opacity-40 disabled:cursor-not-allowed",
                pasteState === "pasted"
                  ? "bg-green-500/15 text-green-400 border border-green-500/30 scale-95"
                  : "bg-muted/70 hover:bg-primary/10 hover:text-primary border border-border hover:border-primary/40 text-muted-foreground hover:scale-[1.03] active:scale-95",
              ].join(" ")}
            >
              {pasteState === "pasted" ? (
                <>
                  <ClipboardCheck className="w-4 h-4 shrink-0" />
                  <span className="hidden sm:inline">Pasted</span>
                </>
              ) : (
                <>
                  <Clipboard className="w-4 h-4 shrink-0" />
                  <span className="hidden sm:inline">Paste</span>
                </>
              )}
            </button>
          </div>
          <Button
            type="submit"
            className="h-14 px-8 rounded-xl text-lg font-semibold"
            disabled={!url || videoInfoMutation.isPending || isJobActive}
          >
            {videoInfoMutation.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : "Get Video"}
          </Button>
        </form>

        {/* Trust badges */}
        <div className="flex flex-wrap justify-center gap-x-6 gap-y-2 text-sm text-muted-foreground pt-2">
          <span className="flex items-center gap-1.5"><CheckCircle className="w-4 h-4 text-green-500" /> Fast Processing</span>
          <span className="flex items-center gap-1.5"><CheckCircle className="w-4 h-4 text-green-500" /> No Registration Required</span>
          <span className="flex items-center gap-1.5"><CheckCircle className="w-4 h-4 text-green-500" /> Works on Desktop &amp; Mobile</span>
        </div>
      </section>

      {/* ── Loading state ── */}
      {videoInfoMutation.isPending && (
        <div className="flex justify-center items-center py-24">
          <div className="flex flex-col items-center gap-4 text-muted-foreground">
            <Loader2 className="w-12 h-12 animate-spin text-primary" />
            <p className="font-medium animate-pulse">Extracting video metadata...</p>
          </div>
        </div>
      )}

      {/* ── Video card + format picker ── */}
      {video && !videoInfoMutation.isPending && (
        <div className="grid md:grid-cols-3 gap-8 items-start animate-in fade-in slide-in-from-bottom-8 duration-500">
          <Card className="md:col-span-1 overflow-hidden border-border bg-card">
            <div className="aspect-video relative bg-black">
              <img src={video.thumbnail} alt={video.title} className="object-cover w-full h-full" />
              <div className="absolute bottom-2 right-2 bg-black/80 backdrop-blur-sm text-white px-2 py-1 rounded text-xs font-mono font-medium">
                {formatDuration(video.duration)}
              </div>
            </div>
            <CardContent className="p-4 space-y-4">
              <div>
                <div className="flex items-start gap-2">
                  <h3 className="font-bold line-clamp-2 leading-tight flex-1" title={video.title}>
                    {video.title}
                  </h3>
                  <CopyButton text={video.title} label="Copy title" successMessage="Title copied!" variant="ghost" size="icon" iconOnly className="flex-shrink-0 mt-0.5 h-7 w-7" />
                </div>
                <p className="text-sm text-muted-foreground mt-1">{video.uploader}</p>
              </div>
              <div className="flex flex-wrap gap-x-4 gap-y-2 text-xs text-muted-foreground">
                <div className="flex items-center gap-1.5"><Eye className="w-3.5 h-3.5" /> {formatViews(video.viewCount)} views</div>
                <div className="flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5" /> {formatDate(video.uploadDate)}</div>
              </div>
              {video.description ? (
                <div className="relative rounded-lg border border-border bg-muted/40 p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Description</span>
                    <CopyButton text={video.description} label="Copy description" successMessage="Copied!" variant="ghost" size="sm" iconOnly={false} className="h-6 text-xs px-2" />
                  </div>
                  <p className="text-xs text-muted-foreground leading-relaxed max-h-24 overflow-y-auto whitespace-pre-wrap">
                    {video.description}
                  </p>
                </div>
              ) : null}
            </CardContent>
          </Card>

          <div className="md:col-span-2 space-y-6">
            {activeJobId && jobStatus ? (
              <Card className="border-primary/50 bg-primary/5 shadow-[0_0_30px_-10px_hsl(var(--primary))]">
                <CardContent className="p-8 flex flex-col items-center justify-center text-center space-y-6">
                  {isJobActive && (
                    <>
                      <Loader2 className="w-12 h-12 animate-spin text-primary" />
                      <div className="space-y-2 w-full max-w-sm">
                        <h3 className="text-xl font-bold">Processing Video...</h3>
                        <p className="text-muted-foreground text-sm">Please wait while we prepare your download.</p>
                        {jobStatus.progress != null && (
                          <div className="space-y-2 pt-4">
                            <div className="flex justify-between text-sm font-medium font-mono">
                              <span>{jobStatus.progress.toFixed(1)}%</span>
                            </div>
                            <Progress value={jobStatus.progress} className="h-2" />
                          </div>
                        )}
                      </div>
                    </>
                  )}
                  {jobDone && jobStatus.downloadUrl && (
                    <>
                      <CheckCircle className="w-16 h-16 text-green-500" />
                      <div className="space-y-2">
                        <h3 className="text-2xl font-bold text-green-500">Ready to Download</h3>
                        <p className="text-muted-foreground">Your file has been processed successfully.</p>
                      </div>
                      <a href={jobStatus.downloadUrl} download={jobStatus.filename || "video"} className="w-full max-w-sm">
                        <Button size="lg" className="w-full font-bold text-lg h-14 bg-green-600 hover:bg-green-700 text-white gap-2">
                          <Download className="w-5 h-5" /> Download File
                        </Button>
                      </a>
                    </>
                  )}
                  {jobFailed && (
                    <>
                      <AlertTriangle className="w-16 h-16 text-destructive" />
                      <div className="space-y-2">
                        <h3 className="text-2xl font-bold text-destructive">Processing Failed</h3>
                        <p className="text-muted-foreground">{jobStatus.error || "An unknown error occurred."}</p>
                      </div>
                      <Button variant="outline" onClick={() => setActiveJobId(null)}>Try Another Format</Button>
                    </>
                  )}
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                <h3 className="text-xl font-semibold flex items-center gap-2">
                  <FileVideo className="w-5 h-5 text-primary" /> Choose Format
                </h3>
                <div className="grid gap-3">
                  {video.formats.map((format) => (
                    <div
                      key={format.formatId}
                      className="flex items-center justify-between p-4 rounded-xl border border-border bg-card hover:border-primary/50 transition-colors group"
                    >
                      <div className="flex items-center gap-4">
                        <div className="bg-muted p-2 rounded-lg">
                          {format.vcodec !== "none" ? <FileVideo className="w-5 h-5" /> : <FileAudio className="w-5 h-5" />}
                        </div>
                        <div>
                          <div className="font-semibold flex items-center gap-2">
                            {format.quality}
                            <span className="text-xs uppercase bg-secondary text-secondary-foreground px-1.5 py-0.5 rounded font-mono">.{format.ext}</span>
                          </div>
                          <div className="text-xs text-muted-foreground mt-1 flex items-center gap-2">
                            {format.resolution && <span>{format.resolution}</span>}
                            {format.fps && <span>• {format.fps}fps</span>}
                            {format.filesize && <span>• {formatFilesize(format.filesize)}</span>}
                          </div>
                        </div>
                      </div>
                      <Button
                        variant="secondary"
                        className="group-hover:bg-primary group-hover:text-primary-foreground transition-colors"
                        onClick={() => handleDownload(format.formatId)}
                        disabled={startDownloadMutation.isPending}
                      >
                        <Download className="w-4 h-4 mr-2" /> Download
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── How It Works ── */}
      <section aria-labelledby="how-it-works" className="space-y-8">
        <div className="text-center space-y-2">
          <h2 id="how-it-works" className="text-2xl md:text-3xl font-bold tracking-tight">
            Download Videos in Three Simple Steps
          </h2>
          <p className="text-muted-foreground">Fast and straightforward — no experience needed.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {steps.map((s) => (
            <div key={s.n} className="relative flex flex-col items-center text-center p-6 rounded-2xl border border-border bg-card gap-4">
              <div className="w-12 h-12 rounded-full bg-primary/10 border-2 border-primary/30 flex items-center justify-center text-primary font-extrabold text-xl">
                {s.n}
              </div>
              <h3 className="font-semibold text-lg">{s.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Features ── */}
      <section aria-labelledby="features" className="space-y-8">
        <div className="text-center space-y-2">
          <h2 id="features" className="text-2xl md:text-3xl font-bold tracking-tight">
            Everything You Need in One Place
          </h2>
          <p className="text-muted-foreground">YTOUDown is built for speed, simplicity, and compatibility.</p>
        </div>
        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-5">
          {features.map((f) => {
            const Icon = f.icon;
            return (
              <Card key={f.title} className="border-border">
                <CardContent className="pt-6 pb-6 space-y-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <h3 className="font-semibold">{f.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </section>

      {/* ── Why Users Love YTOUDown ── */}
      <section aria-labelledby="why-users" className="rounded-2xl border border-border bg-card p-8 md:p-12 space-y-4">
        <h2 id="why-users" className="text-2xl md:text-3xl font-bold tracking-tight">Why Users Love YTOUDown</h2>
        <p className="text-muted-foreground leading-relaxed">
          Thousands of users prefer simple tools that work efficiently without unnecessary distractions.
          YTOUDown is built with a modern interface, responsive design, and fast performance to provide
          an enjoyable experience across all devices.
        </p>
        <p className="text-muted-foreground leading-relaxed">
          Whether you're using Chrome, Firefox, Edge, Safari, Opera, or Brave, our platform is
          optimized to deliver consistent performance. Unlike many websites cluttered with unnecessary
          steps, YTOUDown focuses on a streamlined experience — from pasting your YouTube URL to
          selecting quality and downloading in seconds.
        </p>
      </section>

      {/* ── Works Everywhere ── */}
      <section aria-labelledby="compatibility" className="space-y-8">
        <div className="text-center space-y-2">
          <h2 id="compatibility" className="text-2xl md:text-3xl font-bold tracking-tight">
            Compatible with All Major Devices &amp; Browsers
          </h2>
          <p className="text-muted-foreground">Use YTOUDown on any modern device without installing anything.</p>
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="border-border">
            <CardContent className="pt-6 pb-6 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Monitor className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-semibold text-lg">Supported Devices</h3>
              </div>
              <ul className="space-y-2">
                {devices.map((d) => (
                  <li key={d} className="flex items-center gap-2 text-sm text-muted-foreground">
                    <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" /> {d}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
          <Card className="border-border">
            <CardContent className="pt-6 pb-6 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Chrome className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-semibold text-lg">Supported Browsers</h3>
              </div>
              <ul className="space-y-2">
                {browsers.map((b) => (
                  <li key={b} className="flex items-center gap-2 text-sm text-muted-foreground">
                    <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" /> {b}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* ── Benefits ── */}
      <section aria-labelledby="benefits" className="space-y-6">
        <div className="text-center space-y-2">
          <h2 id="benefits" className="text-2xl md:text-3xl font-bold tracking-tight">
            Benefits of Using YTOUDown
          </h2>
        </div>
        <div className="grid sm:grid-cols-2 gap-3">
          {benefits.map((b) => (
            <div key={b} className="flex items-center gap-3 p-4 rounded-xl border border-border bg-card text-sm">
              <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
              <span className="text-muted-foreground">{b}</span>
            </div>
          ))}
        </div>
      </section>

      {/* ── Inline FAQ ── */}
      <section aria-labelledby="home-faq" className="space-y-6">
        <div className="flex items-end justify-between">
          <div>
            <h2 id="home-faq" className="text-2xl md:text-3xl font-bold tracking-tight">
              Common Questions
            </h2>
            <p className="text-muted-foreground mt-1">Quick answers about YTOUDown.</p>
          </div>
          <Link href="/faq">
            <span className="text-sm font-medium text-primary hover:underline cursor-pointer whitespace-nowrap flex items-center gap-1">
              See all questions <ArrowRight className="w-3.5 h-3.5" />
            </span>
          </Link>
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          {[
            {
              q: "What is YTOUDown?",
              a: "YTOUDown is a fast, browser-based YouTube video downloader. Paste a YouTube link, choose an available format, and download — no software or account needed.",
            },
            {
              q: "Is YTOUDown free to use?",
              a: "Yes, completely free. No subscriptions, no premium tiers, and no account required. Download videos without signing up or providing any personal information.",
            },
            {
              q: "Do I need to install any software?",
              a: "No. Everything runs in your web browser. There is no desktop app, no browser extension, and nothing to download to your device before you start.",
            },
            {
              q: "Which devices and browsers are supported?",
              a: "YTOUDown works on Windows, macOS, Linux, Android, iPhone, and tablets. Compatible browsers include Chrome, Firefox, Edge, Safari, Opera, and Brave.",
            },
            {
              q: "How is YTOUDown different from other downloaders?",
              a: "YTOUDown is built for speed and simplicity — no ads, no confusing redirect steps, and no installation required. A clean alternative to services like SaveFrom.net, SnapScooper, or 4K Downloader.",
            },
            {
              q: "What video formats and qualities are available?",
              a: "YTOUDown fetches all formats available for a given video: up to 4K video (MP4/WebM) and audio-only options (M4A, Opus, MP3). The exact list depends on the original upload.",
            },
          ].map((item) => (
            <div key={item.q} className="rounded-xl border border-border bg-card p-5 space-y-2">
              <h3 className="font-semibold text-sm leading-snug">{item.q}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{item.a}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Alternatives / Competitor comparison ── */}
      <section aria-labelledby="alternatives" className="rounded-2xl border border-border bg-card p-8 md:p-10 space-y-5">
        <h2 id="alternatives" className="text-2xl md:text-3xl font-bold tracking-tight">
          Looking for a YouTube Downloader Alternative?
        </h2>
        <p className="text-muted-foreground leading-relaxed">
          If you've used services like <strong className="text-foreground">SaveFrom.net</strong>,{" "}
          <strong className="text-foreground">SaveFrom.space</strong>,{" "}
          <strong className="text-foreground">Samvan.ca</strong>,{" "}
          <strong className="text-foreground">SnapScooper</strong>, or{" "}
          <strong className="text-foreground">4K Downloader</strong> and found them cluttered with ads,
          confusing redirect steps, or requiring software installs — YTOUDown is built to be different.
        </p>
        <div className="grid sm:grid-cols-3 gap-4">
          {[
            { label: "No ads or redirects", desc: "Clean interface from start to finish." },
            { label: "No install needed",   desc: "100% browser-based — visit and download." },
            { label: "No account required", desc: "Paste a URL and go. Nothing else." },
          ].map((item) => (
            <div key={item.label} className="rounded-xl border border-border bg-background p-4 space-y-1">
              <p className="font-semibold text-sm flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" /> {item.label}
              </p>
              <p className="text-xs text-muted-foreground pl-5">{item.desc}</p>
            </div>
          ))}
        </div>
        <div className="pt-1">
          <Link href="/alternatives">
            <span className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline cursor-pointer">
              See the full feature comparison <ArrowRight className="w-4 h-4" />
            </span>
          </Link>
        </div>
      </section>

      {/* ── Why YTOUDown Over Others ── */}
      <section aria-labelledby="why-choose" className="rounded-2xl border border-border bg-card p-8 md:p-12 space-y-4 mb-8">
        <h2 id="why-choose" className="text-2xl md:text-3xl font-bold tracking-tight">
          Why Choose YTOUDown Over Other Downloaders?
        </h2>
        <p className="text-muted-foreground leading-relaxed">
          Unlike many websites that are cluttered with unnecessary steps, YTOUDown focuses on providing
          a streamlined experience. From the moment you paste your YouTube URL to selecting your
          preferred quality, every part of the process is designed to be fast, intuitive, and accessible.
        </p>
        <p className="text-muted-foreground leading-relaxed">
          Our platform is built for speed, simplicity, and compatibility. We continuously improve
          YTOUDown to enhance performance, usability, and compatibility with modern browsers and devices —
          so you always get a reliable, up-to-date experience.
        </p>
        <div className="grid sm:grid-cols-3 gap-4 pt-2">
          {[
            { label: "Speed", text: "Optimized server-side processing via yt-dlp and FFmpeg." },
            { label: "Simplicity", text: "Three steps: paste, choose, download. Nothing more." },
            { label: "Compatibility", text: "Works on any device, any browser, anywhere." },
          ].map((item) => (
            <div key={item.label} className="rounded-xl border border-border bg-background p-4 space-y-1">
              <p className="font-semibold text-sm text-primary">{item.label}</p>
              <p className="text-xs text-muted-foreground leading-relaxed">{item.text}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
