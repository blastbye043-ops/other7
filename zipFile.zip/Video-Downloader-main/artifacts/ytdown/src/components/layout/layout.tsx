import { Link, useLocation } from "wouter";
import { DownloadCloud, History, LayoutGrid, HelpCircle, Info } from "lucide-react";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  const navItems = [
    { href: "/", label: "Downloader", icon: DownloadCloud },
    { href: "/history", label: "History", icon: History },
    { href: "/formats", label: "Formats", icon: LayoutGrid },
    { href: "/faq", label: "FAQ", icon: HelpCircle },
    { href: "/about", label: "About", icon: Info },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground dark">
      <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center mx-auto px-4 md:px-8">
          <Link href="/" className="flex items-center gap-2 mr-8">
            <div className="bg-primary text-primary-foreground p-1.5 rounded-md">
              <DownloadCloud className="w-5 h-5" />
            </div>
            <span className="font-bold text-lg tracking-tight">YTOUDown</span>
          </Link>
          
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
            {navItems.map((item) => (
              <Link 
                key={item.href} 
                href={item.href}
                className={`transition-colors hover:text-primary ${location === item.href ? "text-primary" : "text-muted-foreground"}`}
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 md:px-8 py-8">
        {children}
      </main>

      <footer className="border-t border-border bg-muted/20">

        {/* Legal notices block */}
        <div className="container mx-auto px-4 md:px-8 py-8 md:py-10 space-y-6 text-xs text-muted-foreground leading-relaxed">

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-1.5">
              <p className="font-semibold text-foreground/70 uppercase tracking-wide text-[10px]">Copyright &amp; Content</p>
              <p>
                YTOUDown does not host, store, or distribute any copyrighted media on its own servers.
                All content is processed from publicly accessible sources. Users are solely responsible
                for ensuring they have the legal right to download and use any content.
              </p>
            </div>
            <div className="space-y-1.5">
              <p className="font-semibold text-foreground/70 uppercase tracking-wide text-[10px]">No Affiliation</p>
              <p>
                YTOUDown is an independent platform and is not affiliated with, endorsed by, or sponsored
                by YouTube, Google, Meta, TikTok, X (Twitter), Instagram, Facebook, Vimeo, or any other
                platform. All trademarks are the property of their respective owners.
              </p>
            </div>
            <div className="space-y-1.5">
              <p className="font-semibold text-foreground/70 uppercase tracking-wide text-[10px]">Disclaimer</p>
              <p>
                YTOUDown is provided for educational and lawful personal use only. Users are responsible
                for ensuring their use of downloaded content complies with applicable copyright laws,
                platform terms, and local regulations. YTOUDown accepts no responsibility for misuse.
              </p>
            </div>
            <div className="space-y-1.5">
              <p className="font-semibold text-foreground/70 uppercase tracking-wide text-[10px]">Cookies &amp; Advertising</p>
              <p>
                This site may use cookies to improve functionality, analyze traffic, and support
                advertising services. Third-party vendors including Google may use cookies to serve
                or personalize ads. By using YTOUDown you consent to cookies as described in our{" "}
                <Link href="/cookies" className="text-primary/80 hover:text-primary underline">Cookie Policy</Link>.
              </p>
            </div>
          </div>

          {/* DMCA strip */}
          <p className="border-t border-border/40 pt-5">
            <strong className="text-foreground/60">DMCA:</strong>{" "}
            If you believe content associated with YTOUDown infringes your intellectual property rights,
            submit a notice via our <Link href="/dmca" className="text-primary/80 hover:text-primary underline">DMCA Policy page</Link>.
            We review valid copyright complaints promptly and take appropriate action.
          </p>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-border/40">
          <div className="container mx-auto px-4 md:px-8 py-5 flex flex-col gap-4">
            <div className="flex items-center gap-2">
              <DownloadCloud className="w-4 h-4 text-primary" />
              <span className="text-sm font-semibold">YTOUDown</span>
              <span className="text-sm text-muted-foreground">© {new Date().getFullYear()} · All Rights Reserved.</span>
            </div>

            <p className="text-xs text-muted-foreground leading-relaxed">
              YTOUDown is an independent online video downloader and is not affiliated with YouTube,
              Google, Meta, TikTok, X (Twitter), Instagram, Facebook, Vimeo, or any other platform.
            </p>

            <div className="flex flex-wrap gap-x-4 gap-y-2 text-xs text-muted-foreground">
              <Link href="/about" className="hover:text-foreground transition-colors">About</Link>
              <Link href="/faq" className="hover:text-foreground transition-colors">FAQ</Link>
              <Link href="/formats" className="hover:text-foreground transition-colors">Formats</Link>
              <Link href="/alternatives" className="hover:text-foreground transition-colors">Alternatives</Link>
              <Link href="/contact" className="hover:text-foreground transition-colors">Contact</Link>
              <Link href="/privacy" className="hover:text-foreground transition-colors">Privacy Policy</Link>
              <Link href="/terms" className="hover:text-foreground transition-colors">Terms of Service</Link>
              <Link href="/cookies" className="hover:text-foreground transition-colors">Cookie Policy</Link>
              <Link href="/dmca" className="hover:text-foreground transition-colors">DMCA</Link>
              <Link href="/copyright" className="hover:text-foreground transition-colors">Copyright Policy</Link>
              <Link href="/disclaimer" className="hover:text-foreground transition-colors">Disclaimer</Link>
            </div>
          </div>
        </div>

      </footer>
    </div>
  );
}
