import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Toaster } from "sonner";
import { Layout } from "@/components/layout/layout";
import Home from "@/pages/home";
import HistoryPage from "@/pages/history";
import FormatsPage from "@/pages/formats";
import FAQPage from "@/pages/faq";
import AboutPage from "@/pages/about";
import PrivacyPage from "@/pages/privacy";
import TermsPage from "@/pages/terms";
import AlternativesPage from "@/pages/alternatives";
import CookiePolicyPage from "@/pages/cookie-policy";
import DMCAPage from "@/pages/dmca";
import CopyrightPage from "@/pages/copyright";
import DisclaimerPage from "@/pages/disclaimer";
import ContactPage from "@/pages/contact";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30000,
      retry: 1,
    },
  },
});

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/history" component={HistoryPage} />
        <Route path="/formats" component={FormatsPage} />
        <Route path="/faq" component={FAQPage} />
        <Route path="/about" component={AboutPage} />
        <Route path="/privacy" component={PrivacyPage} />
        <Route path="/terms" component={TermsPage} />
        <Route path="/alternatives" component={AlternativesPage} />
        <Route path="/cookies" component={CookiePolicyPage} />
        <Route path="/dmca" component={DMCAPage} />
        <Route path="/copyright" component={CopyrightPage} />
        <Route path="/disclaimer" component={DisclaimerPage} />
        <Route path="/contact" component={ContactPage} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster richColors position="top-right" />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
