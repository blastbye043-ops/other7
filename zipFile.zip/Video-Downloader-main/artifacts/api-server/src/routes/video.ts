import { Router, type IRouter } from "express";
import { spawn } from "child_process";
import path from "path";
import fs from "fs";
import { randomUUID } from "crypto";
import { db, downloadsTable } from "@workspace/db";
import {
  GetVideoInfoBody,
  StartDownloadBody,
  GetDownloadStatusParams,
} from "@workspace/api-zod";
import { logger } from "../lib/logger";
import { infoLimiter, downloadLimiter } from "../middlewares/rate-limit";
import { startCleanupScheduler } from "../lib/cleanup";

const router: IRouter = Router();

const YT_DLP_PATH = process.env.YT_DLP_PATH || "/home/runner/workspace/.pythonlibs/bin/yt-dlp";
const FFMPEG_PATH = process.env.FFMPEG_PATH || "/nix/store/k28ypnisbhajg3x1kv5hy7h2vjbajkvy-replit-runtime-path/bin/ffmpeg";

const workspaceRoot = process.cwd().endsWith(path.join("artifacts", "api-server"))
  ? path.resolve(process.cwd(), "../..")
  : process.cwd();

const downloadsDir = path.resolve(workspaceRoot, "artifacts/api-server/downloads");
if (!fs.existsSync(downloadsDir)) {
  fs.mkdirSync(downloadsDir, { recursive: true });
}

type JobStatus = "pending" | "processing" | "done" | "failed";

interface Job {
  jobId: string;
  status: JobStatus;
  url: string;
  formatId: string;
  audioOnly: boolean;
  progress: number | null;
  downloadUrl: string | null;
  filename: string | null;
  error: string | null;
  createdAt: string;
  title: string | null;
  thumbnail: string | null;
  ext: string | null;
}

const jobs = new Map<string, Job>();

startCleanupScheduler(downloadsDir, jobs);

function runYtDlp(args: string[]): Promise<string> {
  return new Promise((resolve, reject) => {
    const proc = spawn(YT_DLP_PATH, args, { timeout: 60000 });
    let stdout = "";
    let stderr = "";
    proc.stdout.on("data", (d: Buffer) => { stdout += d.toString(); });
    proc.stderr.on("data", (d: Buffer) => { stderr += d.toString(); });
    proc.on("close", (code) => {
      if (code === 0) resolve(stdout.trim());
      else reject(new Error(stderr || `yt-dlp exited with code ${code}`));
    });
    proc.on("error", reject);
  });
}

router.post("/video/info", infoLimiter, async (req, res) => {
  const parsed = GetVideoInfoBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid URL" });
    return;
  }

  const { url } = parsed.data;

  if (!url.includes("youtube.com") && !url.includes("youtu.be")) {
    res.status(400).json({ error: "Only YouTube URLs are supported" });
    return;
  }

  try {
    const jsonStr = await runYtDlp([
      "--dump-json",
      "--no-playlist",
      "--no-warnings",
      "--ffmpeg-location", FFMPEG_PATH,
      url,
    ]);

    const info = JSON.parse(jsonStr);

    const videoFormats: Array<{
      formatId: string;
      ext: string;
      quality: string;
      resolution: string | null;
      filesize: number | null;
      vcodec: string | null;
      acodec: string | null;
      fps: number | null;
      tbr: number | null;
    }> = [];

    const seen = new Set<string>();

    if (info.formats) {
      for (const f of info.formats) {
        if (!f.format_id) continue;
        const ext = f.ext || "mp4";
        const resolution = f.resolution || (f.height ? `${f.height}p` : null);
        const quality = resolution || f.format_note || f.format || "unknown";
        const key = `${quality}-${ext}`;
        if (seen.has(key)) continue;
        seen.add(key);

        videoFormats.push({
          formatId: f.format_id,
          ext,
          quality,
          resolution,
          filesize: f.filesize || f.filesize_approx || null,
          vcodec: f.vcodec || null,
          acodec: f.acodec || null,
          fps: f.fps || null,
          tbr: f.tbr || null,
        });
      }
    }

    videoFormats.sort((a, b) => {
      const getHeight = (q: string) => parseInt(q.replace("p", "")) || 0;
      return getHeight(b.resolution || b.quality) - getHeight(a.resolution || a.quality);
    });

    const audioOnly = videoFormats.filter(f => f.vcodec === "none" || f.acodec !== "none" && !f.vcodec);
    const videoWithAudio = videoFormats.filter(f => f.vcodec && f.vcodec !== "none" && f.acodec && f.acodec !== "none");
    const videoOnly = videoFormats.filter(f => f.vcodec && f.vcodec !== "none" && (!f.acodec || f.acodec === "none"));

    const bestFormats = [
      ...videoWithAudio.slice(0, 8),
      ...videoOnly.slice(0, 4),
      ...audioOnly.slice(0, 4),
    ];

    res.json({
      id: info.id,
      title: info.title || "Unknown Title",
      url: info.webpage_url || url,
      formats: bestFormats,
      duration: info.duration || null,
      thumbnail: info.thumbnail || "",
      uploader: info.uploader || info.channel || "Unknown",
      viewCount: info.view_count || null,
      uploadDate: info.upload_date || null,
      description: info.description ? info.description.slice(0, 500) : null,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get video info");
    res.status(422).json({ error: "Failed to fetch video info. Please check the URL and try again." });
  }
});

router.post("/video/download", downloadLimiter, async (req, res) => {
  const parsed = StartDownloadBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request" });
    return;
  }

  const { url, formatId, audioOnly } = parsed.data;
  const jobId = randomUUID();
  const job: Job = {
    jobId,
    status: "pending",
    url,
    formatId,
    audioOnly: audioOnly || false,
    progress: 0,
    downloadUrl: null,
    filename: null,
    error: null,
    createdAt: new Date().toISOString(),
    title: null,
    thumbnail: null,
    ext: null,
  };
  jobs.set(jobId, job);

  res.json({
    jobId,
    status: job.status,
    url,
    formatId,
    progress: job.progress,
    downloadUrl: null,
    filename: null,
    error: null,
    createdAt: job.createdAt,
  });

  processDownload(jobId).catch((err) => {
    logger.error({ err, jobId }, "Download job failed");
  });
});

async function processDownload(jobId: string) {
  const job = jobs.get(jobId);
  if (!job) return;

  job.status = "processing";
  job.progress = 5;

  const outputTemplate = path.join(downloadsDir, `${jobId}.%(ext)s`);
  const args = [
    "--no-playlist",
    "--no-warnings",
    "--ffmpeg-location", FFMPEG_PATH,
    "-f", job.formatId,
    "--output", outputTemplate,
    "--print-json",
  ];

  if (job.audioOnly) {
    args.push("--extract-audio", "--audio-format", "mp3");
  }

  args.push(job.url);

  try {
    const output = await runYtDlp(args);

    let info: { title?: string; thumbnail?: string; ext?: string; filesize?: number; filesize_approx?: number } = {};
    try {
      info = JSON.parse(output);
    } catch {
      info = {};
    }

    const files = fs.readdirSync(downloadsDir).filter(f => f.startsWith(jobId));
    if (files.length === 0) {
      throw new Error("Downloaded file not found");
    }

    const filename = files[0];
    const ext = path.extname(filename).slice(1);
    const filesize = fs.statSync(path.join(downloadsDir, filename)).size;

    job.status = "done";
    job.progress = 100;
    job.filename = filename;
    job.downloadUrl = `/api/video/file/${filename}`;
    job.title = info.title || "Video";
    job.thumbnail = info.thumbnail || null;
    job.ext = ext;

    await db.insert(downloadsTable).values({
      url: job.url,
      title: job.title,
      thumbnail: job.thumbnail,
      format: job.formatId,
      ext,
      filesize,
      status: "done",
    });
  } catch (err) {
    job.status = "failed";
    job.error = err instanceof Error ? err.message : "Download failed";
    logger.error({ err, jobId }, "Download processing failed");

    await db.insert(downloadsTable).values({
      url: job.url,
      title: job.title || "Unknown",
      thumbnail: null,
      format: job.formatId,
      ext: "unknown",
      filesize: null,
      status: "failed",
    }).catch(() => {});
  }
}

router.get("/video/download/:jobId", (req, res) => {
  const parsed = GetDownloadStatusParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid job ID" });
    return;
  }

  const job = jobs.get(parsed.data.jobId);
  if (!job) {
    res.status(404).json({ error: "Job not found" });
    return;
  }

  res.json({
    jobId: job.jobId,
    status: job.status,
    url: job.url,
    formatId: job.formatId,
    progress: job.progress,
    downloadUrl: job.downloadUrl,
    filename: job.filename,
    error: job.error,
    createdAt: job.createdAt,
  });
});

router.get("/video/file/:filename", (req, res) => {
  const filename = req.params.filename;
  if (!filename || filename.includes("..") || filename.includes("/")) {
    res.status(400).json({ error: "Invalid filename" });
    return;
  }

  const filePath = path.join(downloadsDir, filename);
  if (!fs.existsSync(filePath)) {
    res.status(404).json({ error: "File not found" });
    return;
  }

  res.download(filePath, filename, (err) => {
    if (err) req.log.error({ err }, "Error sending file");
  });
});

export default router;
