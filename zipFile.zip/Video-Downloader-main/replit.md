# YTOUDown

A production-ready YouTube video downloader — paste a URL, pick quality, download. Powered by yt-dlp and FFmpeg, with download history, format browser, FAQ, and About pages.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/ytdown run dev` — run the frontend (port 25301)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite + Tailwind CSS + shadcn/ui + Framer Motion
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)
- Downloader: yt-dlp + FFmpeg

## Where things live

- DB schema: `lib/db/src/schema/downloads.ts`
- API contract: `lib/api-spec/openapi.yaml`
- API routes: `artifacts/api-server/src/routes/` (video.ts, history.ts, formats.ts)
- Frontend pages: `artifacts/ytdown/src/pages/`
- Frontend theme: `artifacts/ytdown/src/index.css`
- Downloads stored in: `artifacts/api-server/downloads/` (created at runtime)

## Architecture decisions

- yt-dlp is invoked via child_process `spawn` on the server side; downloads are stored as files in `artifacts/api-server/downloads/`
- In-memory job map tracks download status (jobId → Job); history is persisted to PostgreSQL
- Frontend polls `GET /api/video/download/:jobId` every 2s while job is pending/processing
- yt-dlp path is `/home/runner/workspace/.pythonlibs/bin/yt-dlp` (installed via pip)
- FFmpeg path is from the Nix store (resolved at startup)

## Product

- Home: Paste YouTube URL → fetch video info → select format → download with progress tracking
- History: All past downloads with stats summary (total count, success rate, total size, popular formats)
- Formats: Browse all supported video/audio formats
- FAQ: 10 common questions about the downloader
- About: Product overview and legal notice

## Gotchas

- After installing new Python packages (yt-dlp), the YT_DLP_PATH env var defaults to the pip install location
- yt-dlp must be installed via `pip install yt-dlp` in the Replit environment
- DB schema changes require `pnpm --filter @workspace/db run push`
- After OpenAPI spec changes, always run codegen before touching types

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
